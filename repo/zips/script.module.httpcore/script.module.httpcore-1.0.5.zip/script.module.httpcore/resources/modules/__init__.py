import sys
sys.modules['_asyncio'] = None  # type: ignore
