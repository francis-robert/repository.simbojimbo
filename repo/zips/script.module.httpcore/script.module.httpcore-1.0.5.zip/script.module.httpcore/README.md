script.module.httpcore
======================

A minimal HTTP client. ⚙️

See https://github.com/encode/httpcore
