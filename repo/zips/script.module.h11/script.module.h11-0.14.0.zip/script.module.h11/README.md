script.module.h11
======================

A pure-Python, bring-your-own-I/O implementation of HTTP/1.1


See https://github.com/python-hyper/h11
