script.module.pyftpdlib
======================

Extremely fast and scalable Python FTP server library packaged for KODI.

See https://github.com/giampaolo/pyftpdlib
