script.module.sniffio
======================

Sniff out which async library your code is running under


See https://github.com/python-trio/sniffio
