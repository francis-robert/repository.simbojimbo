script.module.httpx
======================

A next generation HTTP client for Python. 🦋 packaged for KODI.

See https://github.com/encode/httpx/
