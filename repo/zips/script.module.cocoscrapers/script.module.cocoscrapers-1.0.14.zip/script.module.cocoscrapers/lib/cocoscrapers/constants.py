ADDON = "script.module.cocoscrapers"
