# CatSubs


## Development
CatSubs is a fork of [subloader](https://github.com/denimnani/service.subloader). All credits go to the original developers.

## TODO:

[] - Extract reusable utilities into a common module:
    - logger
    - constants/abstractions for common addon methods
    - router